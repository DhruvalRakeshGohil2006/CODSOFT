package Task4QuizApplication;

public class QuizSummary 
{
    int questionNumber, correctOption, selectedOption;

    public QuizSummary(int questionNumber, int correctOption, int selectedOption) 
    {
        this.questionNumber = questionNumber;
        this.correctOption = correctOption;
        this.selectedOption = selectedOption; 
    }
}
